# Prompt v2 — porte o arquivo de referência

> **Antes de colar:** arraste o arquivo `menu-pasta-ospower.html` para dentro da sessão do Claude Code (ou salve na raiz do projeto e cite o caminho). Sem o arquivo, esse prompt não funciona — a ideia toda é ele **portar** código pronto, não reinterpretar uma descrição.

---

Você tem o arquivo `menu-pasta-ospower.html` neste projeto. Ele é a **referência visual e a fonte da verdade** do menu que eu quero. Abra e leia o arquivo inteiro antes de escrever qualquer código.

Sua tarefa é substituir a navegação atual do sistema por esse menu, portando o arquivo para a stack do projeto. Isso é um **port**, não um redesign: não invente variação, não "melhore" a geometria, não troque a estrutura por um componente de UI que já exista no projeto.

## O que está errado hoje

A navegação atual é uma barra escura com pílulas, onde a aba ativa é só uma pílula pintada de verde. **Isso não é o que eu quero.** Na referência, a aba ativa **deixa de ser pílula**: ela vira uma pasta (estilo pasta de arquivo), o painel de conteúdo é o corpo dessa pasta, e a lingueta da aba nasce grudada no corpo com um canto côncavo fazendo a emenda. Se no fim existir uma pílula representando a aba ativa, o trabalho está errado.

## Regras que não podem mudar

1. A aba selecionada é a lingueta da pasta, no canto superior esquerdo, e é da **mesma cor do corpo** — é isso que cria a ilusão de pasta.
2. As demais abas ficam como pílulas alinhadas à direita, na ordem original da lista.
3. Ao trocar de aba, a que estava ativa **volta pro grupo da direita na posição original dela** e a nova vira a pasta. A ordem do grupo nunca embaralha.
4. A lingueta anima a largura, e o canto côncavo anima o `left` no mesmo tempo e na mesma curva. Se a emenda "descolar" durante a transição, está errado.

## Copie literalmente do arquivo

Copie sem alterar valores:

- as variáveis CSS (`--shell`, `--paper`, `--pill`, `--ink`, `--header`, `--inset`, `--r-*`, `--notch`, `--tab-pad-l`, `--tab-pad-r`);
- a geometria da lingueta, do corpo e do canto côncavo;
- o `radial-gradient` do `.joint` — é ele que desenha o canto côncavo. Não substitua por `box-shadow`, `clip-path`, SVG, borda ou imagem;
- a medição da largura pelo elemento fantasma (`.ghost`), com o **mesmo** padding/fonte/peso da lingueta;
- a animação FLIP das pílulas (`getBoundingClientRect` antes e depois + `el.animate` com `translateX`);
- os tempos e a curva: `420ms cubic-bezier(.2,.8,.2,1)`.

Se algum valor precisar mudar por causa da stack, me avise antes em vez de decidir sozinho.

## Onde mexer

- Localize o componente de navegação atual do sistema e **substitua** ele. Não crie um segundo menu convivendo com o antigo.
- Mantenha as rotas, o estado e a lógica de permissão que já existem — muda só a camada visual e a marcação.
- A paleta muda: a moldura vira cinza escuro (`--shell: #56574F`), a pasta e a lingueta ficam em cinza claro (`--paper: #E3E5DE`) e as pílulas em cinza claro (`--pill: #E9EAE4`) com texto escuro. **Não** use preto nem o verde da marca na barra — o verde fica só nos indicadores dentro do conteúdo.
- Mantenha o bloco "Gerente Teste / Sair" na extremidade direita, separado das pílulas por um divisor fino, com o "Sair" no mesmo estilo de pílula clara.
- O botão redondo com X no canto superior esquerdo é opcional: se não houver nada pra fechar no seu contexto, remova ele e baixe `--tab-pad-l` de `50px` para `28px`.
- Não altere o conteúdo das páginas. O conteúdo do dashboard dentro do arquivo é só recheio de exemplo pra eu enxergar o resultado.

## Qualidade obrigatória

- `role="tablist" / "tab" / "tabpanel"`, `aria-selected`, setas ← → navegando entre abas, foco visível.
- `@media (prefers-reduced-motion: reduce)` zera as transições.
- São 8 abas: quando não couberem, o grupo da direita rola na horizontal sem barra visível (`overflow-x:auto` + `scrollbar-width:none`). A pasta nunca quebra nem sobrepõe as pílulas.
- Sem dependência nova.

## Checklist de aceite — confira item a item antes de dizer que terminou

- [ ] Não existe nenhuma pílula representando a aba ativa.
- [ ] A lingueta e o corpo são da mesma cor e parecem uma peça só.
- [ ] O canto côncavo está encostado na lingueta, sem fresta e sem sobreposição.
- [ ] Trocando de aba, a antiga volta pra posição original dela no grupo.
- [ ] Durante a animação, a emenda acompanha a lingueta sem descolar.
- [ ] O canto superior esquerdo do corpo é reto (radius 0), porque encosta na lingueta.
- [ ] Rodou e comparou com o arquivo de referência lado a lado.

Ao terminar, descreva em 3 linhas o que ficou diferente do arquivo de referência e por quê.
